# E-ᑕOᗰᗰEᖇᑕE ᗩᑭᑭᒪIᑕᗩTIOᑎ ᑌI Iᑎ ᖴᒪᑌTTEᖇ

ᕼI 👋 I ᖇEᑕEᑎTᒪY STᗩᖇTEᗪ ᗯITᕼ ᗩᑎ E-ᑕOᗰᗰEᖇᑕE ᗩᑭᑭ ᗩᑎᗪ ᗪEᑕIᗪEᗪ TO SᕼᗩᖇE ᗰY E᙭ᑭᒪOᖇᗩTIOᑎ. I TᖇIEᗪ TO ᗰᗩKE IT SᒪEEK ᗩᑎᗪ ᗩᑕᑕOᖇᗪIᑎG TO ᒪᗩTEST ᗪESIGᑎ TᖇEᑎᗪS.

## ᖴOᒪᒪOᗯ

- [Twitter](https://www.twitter.com/ishaileshmisra)
- [Instagram](https://www.instagram.com/ishaileshmishra)

## SᑕᖇEEᑎSᕼOTS

<img src="assets/srcn/one.png" width=230> <img src="assets/srcn/two.png" width=230> <img src="assets/srcn/three.png" width=230>

<img src="assets/srcn/four.png" width=230> <img src="assets/srcn/five.png" width=230> <img src="assets/srcn/six.png" width=230>

<b>Iᖴ YOᑌ ᒪIKEᗪ IT, I'ᗰ SᑌᖇE YOᑌ ᗩᖇE GOIᑎG TO ᒪIKE TᕼESE ᗩᒪSO. ᐯISIT ᗷEᒪOᗯ ᒪIᑎKS</b>

[flutter-feed-app](https://github.com/ishaileshmishra/flutter-feed-app)

[flutter_shopping_app](https://github.com/ishaileshmishra/flutter_shopping_app)

[instagram_ui](https://github.com/ishaileshmishra/instagram_ui)

[flutter_developer_portfolio](https://github.com/ishaileshmishra/flutter_developer_portfolio)

[instagram_reels_flutter](https://github.com/ishaileshmishra/instagram_reels_flutter)

[flutter_shopping_app](https://github.com/ishaileshmishra/flutter_shopping_app)

[flutter_news_feed_app](https://github.com/ishaileshmishra/flutter-news-feed-app)

[flutter-ecommerce_cake_app](https://github.com/ishaileshmishra/flutter-ecommerce-cake-app)

[flutter_inventry_app](https://github.com/ishaileshmishra/flutter-inventry-app)

[portfolio_app](https://github.com/ishaileshmishra/portfolio-app)

## ᗩᑭI IᑎᖴOᖇᗰᗩTIOᑎ (ᑌᑎᗪEᖇ ᗪEᐯEᒪOᑭᗰEᑎT)

Need some help? Drop a message to me

<table>
    <tr>
        <td>mshaileshr@gmail.com</td>
    </tr>
</table>

<table>
    <tr>
        <td>Download APK</td>
    </tr>
</table>

[Click To Download](https://github.com/ishaileshmishra/jin_ecomm/blob/master/assets/apk/app-release.apk?raw=true)
