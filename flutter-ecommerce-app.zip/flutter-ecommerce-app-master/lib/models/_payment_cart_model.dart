class PayCard {
  String title;
  String description;
  String image;

  PayCard(
      {required this.title, required this.description, required this.image});
}
